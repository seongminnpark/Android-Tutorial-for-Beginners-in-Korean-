package com.seongminpark.bf;

/**
 * Created by seongmin on 7/30/15.
 */
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.graphics.Color;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.view.View.OnTouchListener;
import android.view.MotionEvent;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.StreamCorruptedException;
import java.util.Random;
import java.util.UUID;

public class BallView extends Activity implements SensorEventListener {
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String NAME = "Bluetooth!";
    AcceptThread acceptThread;
    ConnectThread connectThread;
    ConnectedThread connectedThread;
    int isServer;
    BluetoothSocket passiveSocket = null;
    BluetoothSocket activeSocket = null;

    boolean established = false;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    public static int ballSize = 300;
    BounceView ballView = null;
    public static int screenWidth;
    public static int screenHeight;
    Ball ball;
    ShapeDrawable ballDrawable;
    boolean here;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isServer = getIntent().getExtras().getInt("isServer");
        connectionSetup();
        // Set up sensors.
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager
                .getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        // Set up views.
        ballView = new BounceView(this);
        ballView.setBackgroundColor(randomColor());
        setContentView(ballView);
        // Screen specs.
        DisplayMetrics displaymetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        screenWidth = displaymetrics.widthPixels;
        screenHeight = displaymetrics.heightPixels;
        System.out.print("screenWidth: ");
        System.out.print(screenWidth);
        System.out.print(", screenHeight: ");
        System.out.println(screenHeight);

        // Set up ball.
        ball = new Ball(0,0,0);
        ballDrawable = new ShapeDrawable(new OvalShape());
        // Set up onTouchListner to make a ball on tap.
        ballView.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                System.out.println("touched");
                if (here) {
                int action = event.getAction();
                int x = (int) event.getX();
                int y = (int) event.getY();
                switch(action){
                    case MotionEvent.ACTION_DOWN:
                        // Make new ball.
                        ball.xPosition = (x + ballSize >= screenWidth) ? screenWidth - ballSize : x;
                        ball.yPosition = (y + ballSize >= screenHeight) ? screenHeight - ballSize : y;
                        ball.xVelocity = 0;
                        ball.yVelocity = 0;
                        ballDrawable.getPaint().setColor(ball.color);
                        ballDrawable.setBounds(x, y, x + ballSize, y + ballSize);
                        here = true;
                        ballView.invalidate();
                        break;
                    default:
                        break;
                }}
                return true;
            }});
    }

    private void connectionSetup() {
        if (isServer == 0) {
            BluetoothDevice device = getIntent().getExtras().getParcelable("selected");
            connectThread = new ConnectThread(device);
            connectThread.start();
        }
        else {
            acceptThread = new AcceptThread();
            acceptThread.start();
        }
    }

    private void manageConnection() {
        System.out.println(isServer);
        connectedThread = null;
        if (isServer == 0) {
            try {
                connectedThread = new ConnectedThread(activeSocket);
                connectedThread.start();
            } catch (Exception e) {
                Log.e("Connthread not started", e.getMessage());
            }
        }
        else {
            try {
                connectedThread = new ConnectedThread(passiveSocket);
                connectedThread.start();
            } catch (Exception e) {
                Log.e("Connthread not started", e.getMessage());
            }
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer,
                SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor arg0, int arg1) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (here && event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            int xAcc = (int) event.values[0];
            int yAcc = (int) event.values[1];
            ball.moveBall(screenWidth, screenHeight, xAcc, yAcc);
            ballView.invalidate();
        }
    }

    public class BounceView extends ImageView {


        public BounceView(Context context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (here) {
                if (ball.goneOut) {
                    sendBall(ball);
                } else {
                    ballDrawable.setBounds(
                            ball.xPosition, ball.yPosition,
                            ball.xPosition + ballSize, ball.yPosition + ballSize);
                    System.out.print("x: ");
                    System.out.print(ball.xPosition);
                    System.out.print(", y: ");
                    System.out.println(ball.yPosition);
                    System.out.print("xNext: ");
                    System.out.print(ball.nextXPosition);
                    System.out.print(", yNext: ");
                    System.out.println(ball.nextYPosition);
                    ballDrawable.draw(canvas);
                }
            }
        }
    }

    private int randomColor() {
        Random rand = new Random();
        int r = rand.nextInt(255);
        int g = rand.nextInt(255);
        int b = rand.nextInt(255);
        return Color.rgb(r, g, b);
    }

    private class AcceptThread extends Thread {
        private final BluetoothServerSocket serverSocket;

        public AcceptThread() {
            // Use a temporary object that is later assigned to serverSocket,
            // because serverSocket is final
            BluetoothServerSocket tmp = null;
            try {
                // MY_UUID is the app's UUID string, also used by the client code
                tmp = MainActivity.bluetooth_adapter.listenUsingRfcommWithServiceRecord(NAME, MY_UUID);
            } catch (IOException e) { }
            serverSocket = tmp;
        }

        public void run() {
            //BluetoothSocket socket = null;
            // Keep listening until exception occurs or a socket is returned
            while (true) {
                try {
                    passiveSocket = serverSocket.accept();
                    manageConnection();
                } catch (IOException e) {
                    break;
                }
                // If a connection was accepted
                if (passiveSocket != null) {
                    // Do work to manage the connection (in a separate thread)
                    //manageConnectedSocket(socket);
                    try {
                        serverSocket.close();
                    } catch (IOException e) { }
                    break;
                }
            }
        }

        /** Will cancel the listening socket, and cause the thread to finish */
        public void cancel() {
            try {
                serverSocket.close();
            } catch (IOException e) { }
        }
    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket socket;

        public ConnectThread(BluetoothDevice device) {
            // Use a temporary object that is later assigned to socket,
            // because socket is final
            BluetoothSocket tmp = null;

            // Get a BluetoothSocket to connect with the given BluetoothDevice
            try {
                // MY_UUID is the app's UUID string, also used by the server code
                tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) { }
            socket = tmp;
            activeSocket = socket;
        }

        public void run() {
            // Cancel discovery because it will slow down the connection
            // bluetoothAdapter.cancelDiscovery();

            try {
                // Connect the device through the socket. This will block
                // until it succeeds or throws an exception
                socket.connect();
                manageConnection();
            } catch (IOException connectException) {
                // Unable to connect; close the socket and get out
                try {
                    socket.close();
                } catch (IOException closeException) { }
                return;
            }
            // Do work to manage the connection (in a separate thread)
            //manageConnectedSocket(mmSocket);
        }

        /** Will cancel an in-progress connection, and close the socket */
        public void cancel() {
            try {
                socket.close();
            } catch (IOException e) { }
        }
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket bluetoothSocket;
        private final InputStream inputStream;
        private final OutputStream outputStream;
        private final ObjectOutputStream objectOutputStream;
        private final ObjectInputStream objectInputStream;

        public ConnectedThread(BluetoothSocket socket) {
            established = true;
            bluetoothSocket = socket;
            // Set up normal input, output streams.
            InputStream tmpIn = null;
            OutputStream tmpOut = null;
            try {
                tmpIn = bluetoothSocket.getInputStream();
                tmpOut = bluetoothSocket.getOutputStream();
            } catch (IOException e) {
            }
            inputStream = tmpIn;
            outputStream = tmpOut;
            // Set up object input, output streams.
            ObjectInputStream tmpObIn = null;
            ObjectOutputStream tmpObOut = null;
            try {
                tmpObOut = new ObjectOutputStream(outputStream);
                tmpObOut.flush();
                tmpObIn = new ObjectInputStream(inputStream);
            } catch (StreamCorruptedException e) {
            } catch (IOException e) {
            }
            objectInputStream = tmpObIn;
            objectOutputStream = tmpObOut;
        }

        public void run() {
            while (true) {
                try {
                    Ball tmp = null;
                    tmp = (Ball) objectInputStream.readObject();
                    Ball ball = tmp;
                    handler.obtainMessage(MESSAGE_READ, -1, -1,ball).sendToTarget();
                } catch (IOException e) {
                    break;
                }  catch (ClassNotFoundException e) {
                    break;
                }
            }
        }


        public void write(Ball ball) {
            try {
                objectOutputStream.writeObject(ball);
                handler.obtainMessage(MESSAGE_WRITE, -1, -1,
                        ball).sendToTarget();
                // Share the sent message back to the UI Activity
            } catch (IOException e) {
                System.out.println("write error");
            }
        }

        public void cancel() {
            try {
                bluetoothSocket.close();
            } catch (IOException e) {
            }
        }
    }
    private final Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MESSAGE_WRITE:
                    System.out.println("Write was broadcasted");
                    break;
                case MESSAGE_READ:
                    System.out.println("Read was broadcasted");
                    Ball readBall = (Ball) msg.obj;
                    takeBall(readBall);
                    break;
            }
        }
    };

    public void sendBall(Ball ball) {
        ball.goneOut = false;
        here = false;
        connectedThread.write(ball);
    }

    public void takeBall(Ball sentBall) {
        here = true;
        //
        ball.xPosition = screenWidth/2;
        ball.yPosition = screenHeight/2 + ballSize;
        ball.xVelocity = 0;
        ball.yVelocity = 0;
        ball.color = sentBall.color;
        //
    }


}
