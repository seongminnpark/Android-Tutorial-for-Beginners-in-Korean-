package com.seongminpark.bf;

import android.content.pm.ActivityInfo;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.bluetooth.*;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;


import java.util.ArrayList;
import java.util.UUID;


public class MainActivity extends ActionBarActivity {
    private final static int REQUEST_ENABLE_BT = 22;
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String NAME = "Bluetooth!";
    ListView listView;
    ArrayList<BluetoothDevice> deviceList;
    ArrayAdapter<String> arrayAdapter;
    ScanReciever reciever;
    static BluetoothAdapter bluetooth_adapter;
    Button onButton;
    Button scanButton;
    Button serverButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        deviceList = new ArrayList<>();
        arrayAdapter = new ArrayAdapter<String>(this, R.layout.table_item);

        // Set up Buttons
        onButton = (Button) findViewById(R.id.onButton);
        scanButton = (Button) findViewById(R.id.scanButton);
        serverButton = (Button) findViewById(R.id.alreadyButton);
        onButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askAdapterOn();
            }
        });
        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanForDevices();
            }
        });

        serverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Collect current devices into a set.
                callButtons(1,null);
            }
        });

        // Set up listview
        listView = (ListView) findViewById(R.id.listView);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View v, int position, long id) {
                callButtons(0,deviceList.get(position));
            }
        });

        // Bluetooth setup.
        bluetooth_adapter = BluetoothAdapter.getDefaultAdapter();
        // If device is incapable of using bluetooth:
        if (bluetooth_adapter == null) {
            onButton.setEnabled(false);
            scanButton.setEnabled(false);
            serverButton.setEnabled(false);
        }
        else if (!bluetooth_adapter.isEnabled()) { // If bluetooth is off:
            onButton.setEnabled(true);
            scanButton.setEnabled(false);
            serverButton.setEnabled(false);
        }
        else { // Bluetooth is on and ready:
            onButton.setEnabled(false);
            scanButton.setEnabled(true);
            serverButton.setEnabled(true);
        }

    }

    private class ScanReciever extends BroadcastReceiver  {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action)) {
                System.out.println("Scan started...");
                //discovery starts, we can show progress dialog or perform other tasks
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                System.out.println("Scan finished");
                //discovery finishes, dismis progress dialog
            } else if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                //bluetooth device found
                BluetoothDevice device = (BluetoothDevice) intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                deviceList.add(device);
                arrayAdapter.add(device.getName()+" - Click to pair");
                arrayAdapter.notifyDataSetChanged();
            } else if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                callButtons(1,deviceList.get(deviceList.size()-1));
            }

        }
    };

    protected void askAdapterOn() {
        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
    }

    protected void scanForDevices() {
        IntentFilter filter = new IntentFilter();

        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);

        reciever = new ScanReciever();
        registerReceiver(reciever, filter);
        bluetooth_adapter.startDiscovery();
    }

    protected void callButtons(int server,BluetoothDevice device) {
        bluetooth_adapter.cancelDiscovery();
        Intent toButton = new Intent(getApplicationContext(), BallView.class);
        toButton.putExtra("selected",device);
        if (server == 0) {
            toButton.putExtra("isServer",0);
        }
        else {
            toButton.putExtra("isServer",1);
        }
        startActivity(toButton);
    }


    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK){
                if (bluetooth_adapter.isEnabled()){
                    onButton.setEnabled(false);
                    scanButton.setEnabled(true);
                    serverButton.setEnabled(true);
                }
                else {
                    onButton.setEnabled(true);
                    scanButton.setEnabled(false);
                    serverButton.setEnabled(false);
                }
            }
        }
    }


    @Override
    public void onDestroy() {
        unregisterReceiver(reciever);

        super.onDestroy();
    }




}
