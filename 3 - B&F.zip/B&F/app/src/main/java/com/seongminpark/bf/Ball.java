package com.seongminpark.bf;


import android.graphics.Color;

import java.io.Serializable;
import java.util.Random;

public class Ball implements Serializable{
    int ballSize;
    int halfBallSize;
    int color;
    // Variables to calculate velocity of fall.
    int xPosition;
    int yPosition;
    int xVelocity = 0;
    int yVelocity = 0;
    int nextXPosition;
    int nextYPosition;
    boolean goneOut = false;

    public Ball(int inputXPosition, int inputYPosition, int inputBallSize) {
        xPosition = inputXPosition;
        yPosition = inputYPosition;
        ballSize = inputBallSize;
        halfBallSize = ballSize/2;
        color = randomColor();
    }

    public void moveBall(int screenWidth, int screenHeight, int xAcc, int yAcc) {
        // velocity = initial velocity + acceleration * time
        xVelocity = xVelocity + xAcc;
        yVelocity = yVelocity + yAcc;
        nextXPosition = xPosition - xVelocity;
        nextYPosition = yPosition + yVelocity;
        if (nextXPosition > 0 && nextXPosition + ballSize < screenWidth) xPosition = nextXPosition;
        else xVelocity = 0; // Met screen edge!
        if (nextYPosition > 0 && nextYPosition + ballSize  < screenHeight) yPosition = nextYPosition;
        else if (nextYPosition < 0) goneOut = true;
        else yVelocity = 0; // Met screen edge!
    }

    private int randomColor() {
        Random rand = new Random();
        int r = rand.nextInt(255);
        int g = rand.nextInt(255);
        int b = rand.nextInt(255);
        return Color.rgb(r, g, b);
    }
}