package com.seongminpark.bounce2;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import java.util.Random;

public class Ball {
    int ballSize;
    ShapeDrawable ballDrawable;
    // Variables to calculate velocity of fall.
    int xPosition;
    int yPosition;
    int xVelocity = 0;
    int yVelocity = 0;
    int nextXPosition;
    int nextYPosition;

    public Ball(int inputXPosition, int inputYPosition, int inputBallSize) {
        xPosition = inputXPosition;
        yPosition = inputYPosition;
        ballSize = inputBallSize;

        ballDrawable = new ShapeDrawable(new OvalShape());
        ballDrawable.getPaint().setColor(randomColor());
        ballDrawable.setBounds(xPosition, yPosition, xPosition + ballSize, yPosition + ballSize);
    }

    public void moveBall(int screenWidth, int screenHeight, int xAcc, int yAcc) {
        // velocity = initial velocity + acceleration * time
        xVelocity = xVelocity + xAcc;
        yVelocity = yVelocity + yAcc;
        nextXPosition = xPosition - xVelocity;
        nextYPosition = yPosition + yVelocity;
        if (nextXPosition > 0 && nextXPosition + ballSize < screenWidth) xPosition = nextXPosition;
        else xVelocity = 0; // Met screen edge!
        if (nextYPosition > 0 && nextYPosition + ballSize  < screenHeight) yPosition = nextYPosition;
        else yVelocity = 0; // Met screen edge!
    }

    public void drawBall(Canvas canvas) {
        ballDrawable.setBounds(xPosition, yPosition, xPosition + ballSize, yPosition + ballSize);
        ballDrawable.draw(canvas);
    }

    private int randomColor() {
        Random rand = new Random();
        int r = rand.nextInt(255);
        int g = rand.nextInt(255);
        int b = rand.nextInt(255);
        return Color.rgb(r, g, b);
    }
}