package com.seongminpark.bounce2;

import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.view.View.OnTouchListener;
import android.view.MotionEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor accelerometer;
    public static int ballSize = 300;
    BallView ballView = null;
    public static int screenWidth;
    public static int screenHeight;
    List<Ball> balls = new ArrayList<Ball>();
    Ball ball;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        // Screen specs.
        DisplayMetrics displaymetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        screenWidth = displaymetrics.widthPixels;
        screenHeight = displaymetrics.heightPixels;
        // Set up sensors.
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager
                .getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        // Set up views.
        ballView = new BallView(this);
        ballView.setBackgroundColor(randomColor()); // Pastel Blue.
        setContentView(ballView);
        // Set up onTouchListner to make balls on tap.
        ballView.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                int x = (int) event.getX();
                int y = (int) event.getY();
                switch(action){
                    case MotionEvent.ACTION_DOWN:
                        // Make new ball inside screen boundary.
                        x = (x + ballSize >= screenWidth) ? screenWidth - ballSize : x;
                        y = (y + ballSize >= screenHeight) ? screenHeight - ballSize : y;
                        ball = new Ball(x,y,ballSize);
                        balls.add(ball);
                        ballView.invalidate();
                        break;
                    default:
                        break;
                }
                return true;
            }});
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer,
                SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor arg0, int arg1) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            int xAcc = (int) event.values[0];
            int yAcc = (int) event.values[1];
            for (Ball ball : balls) {
                ball.moveBall(screenWidth, screenHeight, xAcc, yAcc);
            }
            ballView.invalidate();
        }
    }

    public class BallView extends ImageView {


        public BallView(Context context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            for (Ball ball : balls) {
                ball.drawBall(canvas);
            }
        }
    }

    private int randomColor() {
        Random rand = new Random();
        int r = rand.nextInt(255);
        int g = rand.nextInt(255);
        int b = rand.nextInt(255);
        return Color.rgb(r, g, b);
    }

}
