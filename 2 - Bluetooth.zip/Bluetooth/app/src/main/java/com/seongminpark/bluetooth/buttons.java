package com.seongminpark.bluetooth;


import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.UUID;

public class buttons extends Activity {
    public static final int MESSAGE_READ = 9;
    public static final int MESSAGE_WRITE = 14;
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String NAME = "Bluetooth!";
    TextView tv;
    Button button1;
    Button button2;
    Button button3;
    Button unpairB;
    AcceptThread acceptThread;
    ConnectThread connectThread;
    ConnectedThread connectedThread;
    int isServer;
    BluetoothSocket passiveSocket = null;
    BluetoothSocket activeSocket = null;

    boolean cn_established = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buttons);
        isServer = getIntent().getExtras().getInt("isServer");
        connectionSetup();
        // Set up Buttons
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        unpairB = (Button) findViewById(R.id.unpairButton);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonPressed(1);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonPressed(2);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonPressed(3);
            }
        });
        unpairB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unpair();
                finish();
            }
        });

        // Set up textview
        tv = (TextView) findViewById(R.id.textView);
    }

    private void connectionSetup() {
        if (isServer == 0) {
            BluetoothDevice device = getIntent().getExtras().getParcelable("selected");
            connectThread = new ConnectThread(device);
            connectThread.start();
        }
        else {
            acceptThread = new AcceptThread();
            acceptThread.start();
        }
    }

    private void manageConnection() {
        if (isServer == 0) {
            connectedThread = null;
            try {
                connectedThread = new ConnectedThread(activeSocket);
                connectedThread.start();
            } catch (Exception e) {
                Log.e("Connthread not started", e.getMessage());
            }
        }
        else {
            connectedThread = null;
            try {
                connectedThread = new ConnectedThread(passiveSocket);
                connectedThread.start();
            } catch (Exception e) {
                Log.e("Connthread not started", e.getMessage());
            }
        }
    }

    protected void buttonPressed(int i) {
        if (!cn_established) return;
        connectedThread.write(i);
    }

    private void unpair() {
        if (!cn_established) return;
        BluetoothDevice device;
        if (isServer==0) device = activeSocket.getRemoteDevice();
        else device = passiveSocket.getRemoteDevice();
        try {
            Method m = device.getClass().getMethod("removeBond", (Class[]) null);
            m.invoke(device, (Object[]) null);
        } catch (Exception e) {
            Log.e("Unpair failed.", e.getMessage());
        }
    }

    private class AcceptThread extends Thread {
        private final BluetoothServerSocket serverSocket;

        public AcceptThread() {
            // Use a temporary object that is later assigned to mmServerSocket,
            // because mmServerSocket is final
            BluetoothServerSocket tmp = null;
            try {
                // MY_UUID is the app's UUID string, also used by the client code
                tmp = MainActivity.bluetoothAdapter.listenUsingRfcommWithServiceRecord(NAME, MY_UUID);
            } catch (IOException e) { }
            serverSocket = tmp;
        }

        public void run() {
            //BluetoothSocket socket = null;
            // Keep listening until exception occurs or a socket is returned
            while (true) {
                try {
                    passiveSocket = serverSocket.accept();
                    manageConnection();
                } catch (IOException e) {
                    break;
                }
                // If a connection was accepted
                if (passiveSocket != null) {
                    // Do work to manage the connection (in a separate thread)
                    //manageConnectedSocket(socket);
                    try {
                        serverSocket.close();
                    } catch (IOException e) { }
                    break;
                }
            }
        }

    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket socket;

        public ConnectThread(BluetoothDevice device) {
            // Use a temporary object that is later assigned to socket,
            // because socket is final
            BluetoothSocket tmp = null;

            // Get a BluetoothSocket to connect with the given BluetoothDevice
            try {
                // MY_UUID is the app's UUID string, also used by the server code
                tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) { }
            socket = tmp;
            activeSocket = socket;
        }

        public void run() {
            try {
                // Connect the device through the socket. This will block
                // until it succeeds or throws an exception
                socket.connect();
                manageConnection();
            } catch (IOException connectException) {
                // Unable to connect; close the socket and get out
                try {
                    socket.close();
                } catch (IOException closeException) { }
                return;
            }
        }
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket bluetoothSocket;
        private final InputStream inputStream;
        private final OutputStream outputStream;

        public ConnectedThread(BluetoothSocket socket) {
            cn_established = true;
            bluetoothSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;
            try {
                tmpIn = bluetoothSocket.getInputStream();
                tmpOut = bluetoothSocket.getOutputStream();
            } catch (IOException e) {
            }

            inputStream = tmpIn;
            outputStream = tmpOut;
        }

        public void run() {
            byte[] buffer = new byte[4];
            int bytes;
            while (true) {
                try {
                    if (inputStream.available() > 0) {
                        bytes = inputStream.read(buffer);
                        handler.obtainMessage(MESSAGE_READ, bytes, -1,buffer).sendToTarget();
                    }
                } catch (IOException e) {
                    break;
                }
            }
        }

        public void write(int i) {
            try {
                byte[] buffer = new byte[4];
                buffer = intToByteArray(i);
                System.out.println((byte) i);
                outputStream.write(buffer);
                handler.obtainMessage(MESSAGE_WRITE, -1, -1,
                        buffer).sendToTarget();
            } catch (IOException e) {
                System.out.println("write error");
            }
        }
    }

    private final Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MESSAGE_WRITE:
                    byte[] writeBuf = (byte[]) msg.obj;
                    String writeMessage = new String(Integer.toString(byteArrayToInt(writeBuf)));
                    tv.setText(writeMessage);
                    break;
                case MESSAGE_READ:
                    byte[] readBuf = (byte[]) msg.obj;
                    String readMessage = new String(Integer.toString(byteArrayToInt(readBuf)));
                    System.out.println(readMessage);
                    tv.setText(readMessage);
                    break;
            }
        }
    };

    public  byte[] intToByteArray(int value) {
        byte[] byteArray = new byte[4];
        byteArray[0] = (byte)(value >> 24);
        byteArray[1] = (byte)(value >> 16);
        byteArray[2] = (byte)(value >> 8);
        byteArray[3] = (byte)(value);
        return byteArray;
    }

    public  int byteArrayToInt(byte bytes[]) {
        return ((((int)bytes[0] & 0xff) << 24) |
                (((int)bytes[1] & 0xff) << 16) |
                (((int)bytes[2] & 0xff) << 8) |
                (((int)bytes[3] & 0xff)));
    }

}


